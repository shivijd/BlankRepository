package com.capgemini.RegistTest;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;

import com.capgemini.base.TestBase;
import com.capgemini.page.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDef extends TestBase{
	static RegistrationPage register;
	
	public RegistrationStepDef() {
		super();
		setup();
	}
	
	private void setup() {
	initialization().get("file:///C:/Users/SHJADAUN/Desktop/WebPages/RegistrationForm.html");
	register=new RegistrationPage();
	
}

	@Given("^Resitration Page is opening$")
	public void resitration_Page_is_opening() throws Throwable {
	   
	}

	@When("^Registration Page is open$")
	public void registration_Page_is_open() throws Throwable {
	    
	}

	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		assertEquals("Welcome to JobsWorld", register.getTitle1());
	  
	}

	@Given("^Resitration Page is open$")
	public void resitration_Page_is_open() throws Throwable {
	   
	}

	@When("^User leaves the userid blank$")
	public void user_leaves_the_userid_blank() throws Throwable {
		register.setUserid("");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	 
	}

//	@When("^if length is less than (\\d+)$")
//	public void if_length_is_less_than(int arg1) throws Throwable {
//		if(arg1<5)
//	   
//	}

	@Then("^display alert message$")
	public void display_alert_message(String message) throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals(message, alert.getText());
		driver.quit();

	}

	@When("^User Leaves password blank$")
	public void user_Leaves_password_blank() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User leaves name blank$")
	public void user_leaves_name_blank() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User writes address as special cahracters$")
	public void user_writes_address_as_special_cahracters() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("@%@@");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User select country not in dropdown list$")
	public void user_select_country_not_in_dropdown_list() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("South Africa");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User writes zip code in alphabet$")
	public void user_writes_zip_code_in_alphabet() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("defghi");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User writes email id which is wrong$")
	public void user_writes_email_id_which_is_wrong() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User select gender which is not in given form$")
	public void user_select_gender_which_is_not_in_given_form() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("not mention");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User select option which is not present$")
	public void user_select_option_which_is_not_present() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("hindi");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@When("^User select fills all details correctly$")
	public void user_select_fills_all_details_correctly() throws Throwable {
		register.setUserid("Shivi123");
		Thread.sleep(1000);
		register.setPassword("123456789");
		Thread.sleep(1000);
		register.setName("Shivi");
		Thread.sleep(1000);
		register.setAddress("BrejeshwariColony");
		Thread.sleep(1000);
		register.setCountry("India");
		Thread.sleep(1000);
		register.setZipcode("1234567");
		Thread.sleep(1000);
		register.setEmail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		register.setSex("female");
		Thread.sleep(1000);
		register.setLanguage("nonEnglish");
		Thread.sleep(1000);
		register.setAbout("she is very good personality");
		Thread.sleep(1000);
		register.setSubmit();
		
	}

	@Then("^match the alert message$")
	public void match_the_alert_message(String messs) throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals(messs, alert.getText());
		driver.quit();

	}



}
