package com.capgemini.RegistTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/main/resources/com.capgemini.RegistTest",tags="@register")
public class RegistrationPageTest {

}
